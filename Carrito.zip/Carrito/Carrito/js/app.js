// Variables
const carrito = document.querySelector('#carrito');
const ListaCursos = document.querySelector('#lista-cursos');
const VaciarCarrito = document.querySelector('#vaciar-carrito');
const contenedorCarrito = document.querySelector('#lista-carrito tbody');

let articulosCarrito = [];

// Declarar mi gestor de eventos
cargarEventListeners();
function cargarEventListeners() {
    //Este evento se usa para agregar un producto al carrito
    ListaCursos.addEventListener('click', agregarCurso);

    //Este evento se envarga de eliminar un producto del carrito
    carrito.addEventListener('click', eliminarCurso);

    //Este evento vacia el carrito de compras
    VaciarCarrito.addEventListener('click', () =>{
        articulosCarrito=[];
        limpiarHTML();
    });
}

function agregarCurso(e) {
    console.log(e.target.classList);
    e.preventDefault();
    if (e.target.classList.contains('agregar-carrito')) {
        const cursoSeleccionado= e.target.parentElement.parentElement;
        // console.log('Agregando al carrito este curso...!!!');
        leerDatosDelCurso(cursoSeleccionado);
    }
}

function leerDatosDelCurso(curso) {
    // console.log(curso)
    const infoCurso = {
        imagen: curso.querySelector('img').src,
        titulo: curso.querySelector('h4').textContent,
        precio: curso.querySelector('.precio span').textContent,
        id: curso.querySelector('a').getAttribute('data-id'),
        cantidad: 1
    }

    if (articulosCarrito.some(curso => curso.id === infoCurso.id)) {
        const cursos = articulosCarrito.map(curso => {
            if (curso.id === infoCurso.id) {
                curso.cantidad++;
                return curso; //Retornamos el objeto actualizado
            } else {
                return curso; //Retorna lo mismo de al inicio, sin actualizar nada
            }
        });
        articulosCarrito=[...cursos];
    }
    else
        {
            articulosCarrito = [...articulosCarrito, infoCurso];
        }


    mostrarCarritoHTML();

//=== exactamente IGUAL
//some verdadero(si encuentra), sino es falso
//Verificar si el producto ya existe en el CARRITO



}

//imagen no necesita cerrar con la barra inversa (fila 6)
function mostrarCarritoHTML() {
    limpiarHTML();
    articulosCarrito.forEach(curso => {
        const {imagen, titulo, precio,cantidad, id}=curso;
        const row = document.createElement('tr');
        row.innerHTML = `
            <td> <{<img src=${curso.imagen} width="150"> </td> 
            <td>${titulo}</td>
            <td>${precio}</td>
            <td>${cantidad}</td>
            <td> <a href="#" class="borrar-curso" data-id="${id}" >X</td> 
        `
        contenedorCarrito.appendChild(row);
    })
}

function limpiarHTML() {
    //Forma lenta (no optima)
    //contenedorCarrito.innerHTML = '';


    //FORMA OPTIMA
    while(contenedorCarrito.firstChild) {
        contenedorCarrito.removeChild(contenedorCarrito.firstChild);
    }
}


function eliminarCurso(e){
    if(e.target.classList.contains('borrar-curso')){
        const cursoId  =e.target.getAttribute('data-id');
        articulosCarrito=articulosCarrito.filter(curso => curso.id !== cursoId); //Esta funcion va crear otro nuevo arreglo con los que pasan el arreglo
        mostrarCarritoHTML();
    }
}